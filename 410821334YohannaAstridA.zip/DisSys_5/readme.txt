Distributed systems homework 5
by Yohanna Astrid Adhipurusa - 410821334

- The board.json is the database file
- server has classes that allows user to interact with database
- users can be owner or normal user, register when start user.py

features:
- can send message
- can receive message (only see latest message)
- can check inbox
- can check sent messages
- can check all users
- can delete messages